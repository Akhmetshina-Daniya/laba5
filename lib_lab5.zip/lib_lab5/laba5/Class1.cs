﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace laba5
{
    public class Class1
    { 
        public string NameFunc(double numb)
        {
            if (numb % 2 == 0)
                return ("Четное число");
            else
                return ("Нечетное число");
        }
    }
}
